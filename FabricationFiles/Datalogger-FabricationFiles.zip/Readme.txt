December 17/2013

PCB ID: Datalogger
Designer: Nicolas Velasquez

2 layers
size: 40x40mm
Silkscreen on top only

Archives:

1-Datalogger.GTL		Top Layer
2-Datalogger.GBL		Bottom Layer
3-Datalogger.GTS		Top SolderMask
4-Datalogger.GBS		Bottom Soldermask
5-Datalogger.GTO		Top Overlay
Edge-Datalogger.GKO		edge of board
Datalogger-NCDrill.XLN		NC Drill Files
Datalogger-BoardEdgeRout.txt	Board edge routing file